<div>
    <img src= '<?php echo e(asset('/storage/logo_sidema.webp')); ?>' alt="DEMA Poltekkes" width="200">
</div>
<?php /**PATH C:\xampp\htdocs\demaPoltekkes-app\resources\views/vendor/filament-panels/components/logo.blade.php ENDPATH**/ ?>