<?php

namespace App\Filament\Resources\QnaResource\Pages;

use App\Filament\Resources\QnaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateQna extends CreateRecord
{
    protected static string $resource = QnaResource::class;
}
